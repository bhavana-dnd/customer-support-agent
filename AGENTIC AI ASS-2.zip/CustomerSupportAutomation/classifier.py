from state import SupportState

def classify_intent(state: SupportState):
    query = state["query"].lower()

    if any(word in query for word in ["price", "pricing", "subscription", "plan"]):
        state["intent"] = "sales"

    elif any(word in query for word in ["password", "login", "account", "profile"]):
        state["intent"] = "account"

    elif any(word in query for word in ["refund", "payment", "invoice", "billing"]):
        state["intent"] = "billing"

    elif any(word in query for word in ["error", "crash", "bug", "install", "upload"]):
        state["intent"] = "technical"

    elif "previous support issue" in query:
        state["intent"] = "memory"

    else:
        state["intent"] = "unknown"

    return state