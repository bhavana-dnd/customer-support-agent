from graph import graph
from supervisor import supervisor_agent

while True:
    query = input("\nCustomer: ")

    if query.lower() == "exit":
        break

    state = {
        "customer_name": "David",
        "query": query,
        "intent": "",
        "retrieved_context": "",
        "response": "",
        "approval_required": False,
        "approved": False,
        "conversation_history": [],
    }

    try:
        result = graph.invoke(state)

        
        result = supervisor_agent(result)


        print("\nAI Support:")
        print(result["response"])

    except Exception as e:
        print("\nERROR:")
        print(type(e).__name__)
        print(e)