from memory import save_conversation, get_previous_issue

save_conversation("David", "I have a billing issue")

save_conversation("David", "What was my previous issue?")

print(get_previous_issue("David"))