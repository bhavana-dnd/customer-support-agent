from langgraph.graph import StateGraph, END

from state import SupportState
from classifier import classify_intent
from approval import check_approval
from agents import (
    sales_agent,
    technical_agent,
    billing_agent,
    account_agent,
    memory_agent,
    unknown_agent,
)


# Route based on intent
def route_query(state: SupportState):
    return state["intent"]


# Create workflow
workflow = StateGraph(SupportState)

# ==========================
# Add Nodes
# ==========================
workflow.add_node("classifier", classify_intent)
workflow.add_node("approval_check", check_approval)

workflow.add_node("sales", sales_agent)
workflow.add_node("technical", technical_agent)
workflow.add_node("billing", billing_agent)
workflow.add_node("account", account_agent)
workflow.add_node("memory", memory_agent)
workflow.add_node("unknown", unknown_agent)

# ==========================
# Entry Point
# ==========================
workflow.set_entry_point("classifier")

# ==========================
# Flow
# ==========================
workflow.add_edge("classifier", "approval_check")

# Route to the correct agent
workflow.add_conditional_edges(
    "approval_check",
    route_query,
    {
        "sales": "sales",
        "technical": "technical",
        "billing": "billing",
        "account": "account",
        "memory": "memory",
        "unknown": "unknown",
    },
)

# ==========================
# End Nodes
# ==========================
workflow.add_edge("sales", END)
workflow.add_edge("technical", END)
workflow.add_edge("billing", END)
workflow.add_edge("account", END)
workflow.add_edge("memory", END)
workflow.add_edge("unknown", END)

# Compile graph
graph = workflow.compile()