import sqlite3

# Connect to SQLite database
conn = sqlite3.connect("memory.db")
cursor = conn.cursor()

# Create table if it doesn't exist
cursor.execute("""
CREATE TABLE IF NOT EXISTS conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_name TEXT,
    query TEXT
)
""")

conn.commit()


def save_conversation(customer_name, query):
    cursor.execute(
        "INSERT INTO conversations (customer_name, query) VALUES (?, ?)",
        (customer_name, query)
    )
    conn.commit()


def get_previous_issue(customer_name):
    cursor.execute("""
    SELECT query
    FROM conversations
    WHERE customer_name = ?
    AND query NOT LIKE '%previous%'
    ORDER BY id DESC
    LIMIT 1
    """, (customer_name,))

    row = cursor.fetchone()

    if row:
       return row[0]

    return "No previous issue found."