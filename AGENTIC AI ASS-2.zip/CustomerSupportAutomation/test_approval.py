from approval import check_approval, human_approval

state = {
    "customer_name": "David",
    "query": "I need a refund for my annual subscription.",
    "intent": "Billing",
    "retrieved_context": "",
    "response": "",
    "approval_required": False,
    "approved": False,
    "conversation_history": [],
}

state = check_approval(state)

print("Approval Required:", state["approval_required"])

if state["approval_required"]:
    state = human_approval(state)

print("Approved:", state["approved"])