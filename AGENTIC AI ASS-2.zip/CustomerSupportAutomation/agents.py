from state import SupportState
from rag import rag_response
from memory import save_conversation, get_previous_issue


def sales_agent(state: SupportState):
    save_conversation(state["customer_name"], state["query"])
    state["response"] = rag_response(state["query"])
    return state


def technical_agent(state: SupportState):
    save_conversation(state["customer_name"], state["query"])
    state["response"] = rag_response(state["query"])
    return state
def billing_agent(state):
    state["response"] = (
        "Your billing issue has been recorded. "
        "Our billing team will contact you shortly. "
        "For refunds or cancellations, human approval is required."
    )
    return state


def account_agent(state: SupportState):
    save_conversation(state["customer_name"], state["query"])
    state["response"] = rag_response(state["query"])
    return state


def memory_agent(state: SupportState):
    previous = get_previous_issue(state["customer_name"])
    state["response"] = f"Your previous support issue was: {previous}"
    return state


def unknown_agent(state: SupportState):
    state["response"] = "Sorry, I couldn't identify your request."
    return state