from supervisor import supervisor_agent

state = {
    "customer_name": "David",
    "query": "I forgot my password",
    "intent": "Account",
    "retrieved_context": "",
    "response": "You can reset your password using the 'Forgot Password' option.",
    "approval_required": False,
    "approved": False,
    "conversation_history": [],
}

state = supervisor_agent(state)

print(state["response"])