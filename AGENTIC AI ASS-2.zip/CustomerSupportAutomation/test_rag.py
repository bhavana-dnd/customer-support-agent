from rag import rag_response

question = input("Ask: ")

print("\n")

print(rag_response(question))