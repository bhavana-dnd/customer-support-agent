from state import SupportState


def supervisor_agent(state: SupportState):

    response = state["response"]

    improved_response = (
        "Supervisor Review:\n\n"
        + response
        + "\n\nThank you for contacting ABC Technologies. "
        "If you need further assistance, please let us know."
    )

    state["response"] = improved_response

    return state
