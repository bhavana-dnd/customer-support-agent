import os
from dotenv import load_dotenv

from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_google_genai import ChatGoogleGenerativeAI

load_dotenv()

# Load documents
documents = []

files = [
    "documents/pricing.txt",
    "documents/policy.txt",
    "documents/faq.txt",
    "documents/technical_manual.txt"
]

for file in files:
    loader = TextLoader(file)
    documents.extend(loader.load())

# Split text
splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,
    chunk_overlap=50
)

docs = splitter.split_documents(documents)

# Embeddings
embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

# Vector DB
db = Chroma.from_documents(
    docs,
    embeddings,
    persist_directory="chroma_db"
)

retriever = db.as_retriever()

# LLM
llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    temperature=0
)

# RAG function
def rag_response(question):

    retrieved_docs = retriever.invoke(question)

    context = "\n\n".join([doc.page_content for doc in retrieved_docs])

    prompt = f"""
Use only the context below to answer.

Context:
{context}

Question:
{question}
"""

    response = llm.invoke(prompt)

    return response.content