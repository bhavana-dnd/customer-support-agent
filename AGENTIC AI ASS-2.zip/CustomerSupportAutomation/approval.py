from state import SupportState

HIGH_RISK_KEYWORDS = [
    "refund",
    "subscription cancellation",
    "cancel subscription",
    "account closure",
    "close account",
    "compensation",
    "management",
    "manager",
    "escalate"
]


def check_approval(state: SupportState):
    query = state["query"].lower()

    state["approval_required"] = any(
        keyword in query for keyword in HIGH_RISK_KEYWORDS
    )

    return state


def human_approval(state: SupportState):
    print("\n===== HUMAN SUPERVISOR =====")
    print("Customer Query:", state["query"])

    decision = input("Approve this request? (yes/no): ").strip().lower()

    state["approved"] = (decision == "yes")

    return state